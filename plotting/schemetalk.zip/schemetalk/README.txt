
This talk was presented directly in Stata using the Viewer and Stata Markup
and Control Language (SMCL) for the slides.  To view the slides from the talk
perform the following steps.

    1) Unzip these files into their own directory.  The zip file will create
       the directory "schemetalk" which will contain all of the files for the
       talk.

    2) Start Stata and make the Stata's current working directory the one
       where the talk was unzipped, using for example the -cd- command.

    3) In Stata, type -view talk.smcl-.

    4) Click each blue highlighted link on each slide.

       Some links view files (particularly scheme files) and some execute
       Stata commands.

       On the "Let's create a scheme slide" be sure to click both the change
       to be made on the left (which shows the edits to the scheme file) and
       the "graph" link on the right (which draws the graph).

       (Occasionally you may want to use the "Back" button on the Viewer to
       return from a scheme file being viewed or a help file to a slide.)

    5) Use the routing links at the bottom of the slides to move among the
       slides.
          
             ">>" means move to the next slide
          
             "<<" means move to the previous slide
           
             "index" takes you to an index of all the slides

<end>
